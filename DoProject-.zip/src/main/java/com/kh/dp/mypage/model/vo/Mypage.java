package com.kh.dp.mypage.model.vo;

public class Mypage {

}
