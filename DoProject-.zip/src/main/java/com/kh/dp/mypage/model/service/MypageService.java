package com.kh.dp.mypage.model.service;

public interface MypageService {

}
