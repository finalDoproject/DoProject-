package com.kh.dp.mypage.model.dao;

public interface MypageDao {

}
