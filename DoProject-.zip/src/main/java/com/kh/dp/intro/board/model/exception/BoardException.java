package com.kh.dp.intro.board.model.exception;

public class BoardException extends RuntimeException {

	public BoardException() {
		super();
	}

	public BoardException(String message) {
		super(message);
	}
	
}
